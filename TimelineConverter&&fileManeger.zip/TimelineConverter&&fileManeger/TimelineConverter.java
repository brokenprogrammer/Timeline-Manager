package csProject;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

public class TimelineConverter {
	private ArrayList<String> events;
	private PrintStream p;
	
	
	public TimelineConverter(){}

	public TimelineConverter(Timeline t) {
		events.add(t.getName());
		events.add("\n");
		events.addAll(t.outputdata());
	}
	
	public void addInformation(Timeline t){
		events.add(t.getName());
		events.add("\n");
		events.addAll(t.outputdata());
	}
	
	public void save(String pathname ){
		FileOutputStream out;
		
		try{
			out = new FileOutputStream(pathname);
			p = new PrintStream(out);
			for(String s:events){
				p.append(s);
				p.append("\n");
			}
		}catch(Exception e){System.err.println ("Error writing to file");}
	}
	
	public void clear(){
		events.clear();
	}
	
	

}
