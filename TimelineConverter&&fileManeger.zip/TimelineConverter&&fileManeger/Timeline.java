package csProject;

import java.util.ArrayList;

public class Timeline {
	private ArrayList<String> events;
	private String name;
	
	 public ArrayList<String>  outputdata() {
		return events;
	}
	 
	public String getName(){
		return name;
		
	}

}
